// elements
Elements.DIGGS_P1 = '#diggsP1';
Elements.DIGGS_P2 = '#diggsP2';
Elements.DIGG_CONTAINER = '#diggContainer';
Elements.LOADING_CONTAINER ='#loadingContainer';

// templates
Elements.LANGUAGE_SELECTOR_TEMPLATE = '#languageSelector';

// classes
Elements.CLASS_CAMPIGN_LIST_ITEM = '.selectCampaignListItem';


/**
 List of all Elements / Classes of elements used in the DOM
 @class Elements
 @constructor
 **/
function Elements() {
};


